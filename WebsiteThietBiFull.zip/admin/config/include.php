<?php
    include_once "./model/connect.php";
    include_once "../encode.php";
    include_once "./model/upload.php";
    include_once "../define.php";
    include_once "./model/validation.php";
    include_once "./model/deleteImgInFile.php";
    include_once "./model/category.php";
    include_once "./model/nguongoc.php";
    include_once "./model/product.php";
    include_once "./model/account.php";
    include_once "./model/banner.php";
    include_once "./model/introduction.php";
    include_once "./view/header.php";
    include_once "./view/hanleShow/showDanhMuc.php";
    include_once "./view/hanleShow/showNguonGoc.php";
    include_once "./view/hanleShow/showSanPham.php";
    include_once "./view/hanleShow/showAccount.php";
    include_once "./view/hanleShow/showBanner.php";
    include_once "./view/hanleShow/showIntroduction.php";
?>