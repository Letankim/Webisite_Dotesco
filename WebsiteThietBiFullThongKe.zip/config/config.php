<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'appliancestore');

define('PATH_ROOT_APP', dirname(__DIR__));
define('PATH_ROOT_USER', dirname(__DIR__)."/User");
define('NUMBER_PRODUCT_IN_PAGE', 12);
define('PATH_UPLOADS_IMG_USER', "./uploads/");
?>