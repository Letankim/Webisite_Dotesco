<div class="container col-lg-9 col-12 col-sm-12 col-md-7">
    <div class="card-group card_header_product row m-0 mt-xl-5">
    <div class="box-icon-check">
            <i style="color: red;" class='bx bxs-error-circle'></i>
        </div>
        <div class="box-message-success">
            <h2 style="text-align:center;">Đặt hàng chưa thành công.</h2>
            <h3>Đơn hàng của bạn chưa được hoàn thành. Hãy thử lại nhé.</h3>
            <h3>Chân thành cảm ơn.</h3>
        </div>
        <div class="box-back-message">
            <a href="">Quay lại trang sản phẩm</a>
        </div>
    </div>
</div>
</div>
</section>
<script>
    const title = document.querySelector('title');
    title.innerHTML = 'Đặt hàng không thành công';
</script>
