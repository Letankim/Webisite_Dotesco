<div class="container col-lg-9 col-12 col-sm-12 col-md-7">
    <div class="card-group card_header_product row m-0 mt-xl-5">
        <div class="box-icon-check">
            <i class='bx bxs-check-circle'></i>
        </div>
        <div class="box-message-success">
            <h2 style="text-align:center;">Cảm ơn quý khách đã mua hàng tại Dotesco.</h2>
            <h3>Chúng tôi sẽ sớm chuẩn bị hàng để giao đến quý khách trong thời gian sớm nhất.</h3>
            <h3>Chân thành cảm ơn.</h3>
        </div>
        <div class="box-back-message">
            <a href="./?act=san-pham">Quay lại trang sản phẩm</a>
        </div>
    </div>
</div>
</div>
</section>
<script>
    const title = document.querySelector('title');
    title.innerHTML = 'Đặt hàng thành công';
</script>
