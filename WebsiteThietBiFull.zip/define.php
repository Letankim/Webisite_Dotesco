<?php
    define('PATH_UPLOADS', "../uploads/");
    define('PATH_UPLOADS_IMG_USER', "./uploads/");
?>